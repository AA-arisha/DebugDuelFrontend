#include <iostream>
using namespace std;

int main() {
    int energy;
    int sync;
    string state;

    cin >> energy;
    cin >> sync;
    cin >> state;

    if (energy >= 20000 && sync == 1 && state == "green") {
        cout << "Initiating stabilization sequence..." << endl;
        cout << "3" << endl;
        cout << "2" << endl;
        cout << "1" << endl;
        cout << "Universe Stabilized!" << endl;
    } else {
        cout << "WARNING: System instability detected!" << endl;
        cout << "Stabilization Failed — Universe Unstable" << endl;
    }

    return 0;
}