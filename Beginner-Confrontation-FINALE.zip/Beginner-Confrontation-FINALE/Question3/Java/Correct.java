import java.util.Scanner;

public class Correct {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int energy = sc.nextInt();
        int sync = sc.nextInt();
        String state = sc.next();

        if (energy >= 20000 && sync == 1 && state.equals("green")) {
            System.out.println("Initiating stabilization sequence...");
            System.out.println("3");
            System.out.println("2");
            System.out.println("1");
            System.out.println("Universe Stabilized!");
        } else {
            System.out.println("WARNING: System instability detected!");
            System.out.println("Stabilization Failed — Universe Unstable");
        }

        sc.close();
    }
}