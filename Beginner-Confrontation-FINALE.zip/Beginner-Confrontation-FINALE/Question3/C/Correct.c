#include <stdio.h>

int main() {
    int energy;
    int sync;
    char state[10];

    scanf("%d", &energy);
    scanf("%d", &sync);
    scanf("%s", state);

    if (energy >= 20000 && sync == 1 && state[0] == 'g' && state[1] == 'r' && state[2] == 'e' && state[3] == 'e' && state[4] == 'n' && state[5] == '\0') {
        printf("Initiating stabilization sequence...\n");
        printf("3\n");
        printf("2\n");
        printf("1\n");
        printf("Universe Stabilized!\n");
    } else {
        printf("WARNING: System instability detected!\n");
        printf("Stabilization Failed — Universe Unstable\n");
    }

    return 0;
}