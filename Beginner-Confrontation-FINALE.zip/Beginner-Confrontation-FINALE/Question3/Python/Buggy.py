energyy = int(input())
sync = int(input())
state = input()

if (energy >= 20000 or sync == 1) or state is "green":
    print("Initiating stabilization sequence...")
    print("3")
    print("2")
    print("5")
    print("Universe Stabilized!")
else:
    print("WARNING: System instability detected!")
    print("Stabilization Failed — Universe Unstable")