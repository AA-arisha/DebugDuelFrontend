energy = int(input())
sync = int(input())
state = input()

if energy >= 20000 and sync == 1 and state == "green":
    print("Initiating stabilization sequence...")
    print("3")
    print("2")
    print("1")
    print("Universe Stabilized!")
else:
    print("WARNING: System instability detected!")
    print("Stabilization Failed — Universe Unstable")