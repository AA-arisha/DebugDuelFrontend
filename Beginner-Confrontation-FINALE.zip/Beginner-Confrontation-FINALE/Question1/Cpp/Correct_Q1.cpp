#include <iostream>
using namespace std;

int main() {
    int grid[10][10];
    int linear_anchor[100];
    int i, j, k = 0;

    for (i = 0; i < 10; i++) {
        for (j = 0; j < 10; j++) {
            cin >> grid[i][j];
        }
    }

    for (i = 0; i < 10; i++) {
        for (j = 0; j < 10; j++) {
            linear_anchor[k] = grid[i][j];
            k++;
        }
    }

    for (i = 0; i < 100; i++) {
        cout << linear_anchor[i] << " ";
    }

    return 0;
}
