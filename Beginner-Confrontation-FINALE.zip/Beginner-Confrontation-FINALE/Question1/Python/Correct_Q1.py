# Correct flattening logic

grid = [[0 for _ in range(10)] for _ in range(10)]
linear_anchor = [0 for _ in range(100)]

for i in range(10):
    for j in range(10):
        grid[i][j] = int(input())

k = 0
for i in range(10):
    for j in range(10):
        linear_anchor[k] = grid[i][j]
        k += 1

for x in linear_anchor:
    print(x, end=" ")
