#include <stdio.h>

int main() {
    int grid[10][10];
    int linear_anchor[100];
    int i, j, k;

    for (i = 0; i < 10; i++) {
        for (j = 0; j < 10; j++) {
            scanf("%d", &grid[i][j]);
        }
    }

    for (i = 0; i < 10; i++) {
        k = 0;                      
        for (j = 0; j < 9; j++) {   
            linear_anchor[k] = grid[i][j];
            k++;
        }
    }

    for (i = 0; i < 100; i++) {
        printf("%d ", linear_anchor[i]);
    }

    return 0;
}
