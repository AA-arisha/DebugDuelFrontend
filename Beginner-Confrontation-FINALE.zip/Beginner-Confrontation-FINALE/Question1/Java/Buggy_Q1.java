import java.util.Scanner;

public class Flatten {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[][] grid = new int[10][10];
        int[] linearAnchor = new int[100];
        int i, j, k;

        for (i = 0; i < 10; i++) {
            for (j = 0; j < 10; j++) {
                grid[i][j] = sc.nextInt();
            }
        }

        for (i = 0; i < 10; i++) {
            k = 0;                    
            for (j = 0; j < 9; j++) { 
                linearAnchor[k] = grid[i][j];
                k++;
            }
        }

        for (i = 0; i < 100; i++) {
            System.out.print(linearAnchor[i] + " ");
        }

        sc.close();
    }
}
