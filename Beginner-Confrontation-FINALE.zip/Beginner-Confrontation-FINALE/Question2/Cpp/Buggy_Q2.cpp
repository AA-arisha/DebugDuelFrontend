#include <iostream>
using namespace std;

int main() {
    int n;
    int arr[100];
    int max1, max2;
    int min1, min2;

    cin >> n;

    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    max1 = max2 = arr[0];   
    min1 = min2 = arr[0];   

    for (int i = 1; i < n; i++) {   

        if (arr[i] > max1) {
            max2 = max1;
            max1 = arr[i];
        } 
        else if (arr[i] > max2) {   
            max2 = arr[i];
        }

        if (arr[i] < min1) {
            min2 = min1;
            min1 = arr[i];
        } 
        else if (arr[i] > min2) {   
            min2 = arr[i];
        }
    }

    cout << "2nd Max: " << max2 << endl;
    cout << "2nd Min: " << min2 << endl;

    return 0;
}
