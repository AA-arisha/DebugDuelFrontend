import java.util.Scanner;

public class BuggyEnergyAnalysis {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int[] arr = new int[100];

        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        int max1 = arr[0], max2 = arr[0];   
        int min1 = arr[0], min2 = arr[0];   

        for (int i = 1; i < n; i++) {        

            if (arr[i] > max1) {
                max2 = max1;
                max1 = arr[i];
            } 
            else if (arr[i] > max2) {        
                max2 = arr[i];
            }

            if (arr[i] < min1) {
                min2 = min1;
                min1 = arr[i];
            } 
            else if (arr[i] > min2) {        
                min2 = arr[i];
            }
        }

        System.out.println("2nd Max: " + max2);
        System.out.println("2nd Min: " + min2);

        sc.close();
    }
}
