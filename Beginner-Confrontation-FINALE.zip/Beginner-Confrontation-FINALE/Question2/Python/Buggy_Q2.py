# Buggy Energy Signature Analysis

n = int(input())
arr = list(map(int, input().split()))

max1 = max2 = arr[0]   
min1 = min2 = arr[0]  

for i in range(1, n):   

    if arr[i] > max1:
        max2 = max1
        max1 = arr[i]
    elif arr[i] > max2:   
        max2 = arr[i]

    if arr[i] < min1:
        min2 = min1
        min1 = arr[i]
    elif arr[i] > min2:   
        min2 = arr[i]

print("2nd Max:", max2)
print("2nd Min:", min2)
