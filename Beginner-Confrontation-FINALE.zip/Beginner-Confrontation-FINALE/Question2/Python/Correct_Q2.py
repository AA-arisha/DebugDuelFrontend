# Correct Energy Signature Analysis

n = int(input())
arr = list(map(int, input().split()))

max1 = -10**18
max2 = -10**18
min1 = 10**18
min2 = 10**18

for x in arr:

    if x > max1:
        if x != max1:
            max2 = max1
        max1 = x
    elif x > max2 and x < max1:
        max2 = x

    if x < min1:
        if x != min1:
            min2 = min1
        min1 = x
    elif x < min2 and x > min1:
        min2 = x

print("2nd Max:", max2)
print("2nd Min:", min2)
