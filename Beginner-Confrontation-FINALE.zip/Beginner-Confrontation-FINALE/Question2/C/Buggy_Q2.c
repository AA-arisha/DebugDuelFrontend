#include <stdio.h>

int main() {
    int n, i;
    int arr[100];
    int max1, max2;
    int min1, min2;

    scanf("%d", &n);

    for (i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    max1 = max2 = arr[0];   
    min1 = min2 = arr[0];   

    for (i = 1; i < n; i++) {   

        if (arr[i] > max1) {
            max2 = max1;
            max1 = arr[i];
        } else if (arr[i] > max2) {   
            max2 = arr[i];
        }

        if (arr[i] < min1) {
            min2 = min1;
            min1 = arr[i];
        } else if (arr[i] > min2) {   
            min2 = arr[i];
        }
    }

    printf("2nd Max: %d\n", max2);
    printf("2nd Min: %d\n", min2);

    return 0;
}
